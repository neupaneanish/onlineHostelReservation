<?php

namespace App\users;

use Illuminate\Database\Eloquent\Model;

class Hostelimage extends Model
{
    protected $fillable = ['hostel_id','image'];
}
