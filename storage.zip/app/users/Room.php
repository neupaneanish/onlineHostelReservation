<?php

namespace App\users;

use Illuminate\Database\Eloquent\Model;

class Room extends Model
{
    //
}
