
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="row">
    <div class="col-sm-6 c0l-md-4 col-lg-3 quick-navigation-parent">
        <div class="quick-navigation">
            <h3>Quick Navigation</h3>
            <p>Hostel Management</p>
            <li><a href="/admin/hostel/create">Add Hostel</a></li>
            <li><a href="/admin/hostel">Hostels List</a></li>
            <li class = "active"><a href="/admin/hostel/manageImage">Manage Images</a></li>
        </div>
    </div>

    <div class="col-sm-6 col-md-8 col-lg-9 left-section-container">
    <?php if(session('Status')): ?>

<div class="list-hostel">
  <h3><?php echo e(session('Status')); ?></h3>
</div>

<?php endif; ?>
      <div class="add-hostel">
        <h3>--<?php echo e($name->name); ?></h3>
        <div class="list-hostel">
        <div class="row">
            <?php if(!empty($images)): ?>
            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- <p><?php echo e($image->image); ?></p> -->
            <div class="col-12 col-xs-12 col-sm-12 col-md-6 col-lg-4 col-xl-4 image-cards">
                <div class="hostel-image-container">
                    <img src="<?php echo e(asset('/uploads/'.$image->image)); ?>" alt="" srcset="">
                    <div class="image-overlay"></div>
                    <form action="/admin/image/delete/<?php echo e($image->id); ?>" method="post">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                    <button type="submit" class = "btn btn-danger">Delete</button>
                    </form>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
          
        </div>
              
    
        </div>
      </div>
    </div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\onlineHostelReservation\resources\views/admin/images/viewImage.blade.php ENDPATH**/ ?>