
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="row">
    <div class="col-sm-12 c0l-md-4 col-lg-3 quick-navigation-parent">
    <div class="quick-navigation">
            <h3>Quick Navigation</h3>
            <p>Hostel Management</p>
            <a href="/admin/hostel/create"><li>Add Hostel</li></a>
            <a href="/admin/hostel"><li class = "active">Hostels List</li></a>
            <a href="/admin/hostel/manageImage"><li>Manage Images</li></a>
        </div>
    </div>

    <div class="col-sm-12 col-md-8 col-lg-9 left-section-container">
    <?php if(session('status')): ?>

<div class="list-hostel">
  <h3><?php echo e(session('status')); ?></h3>
</div>

<?php endif; ?>
      <div class="add-hostel">
        <h3>Hostel List</h3>
        <div class="list-hostel">
            <table class="table table-hover">
                <thead>
                  <tr>
                  <th scope="col">S/N</th>
                    <th scope="col">Hostel Name</th>
                    <th scope="col">Hostel Email</th>
                    <th scope="col">Address</th>
                    <!-- <th scope="col">Phone</th>
                    <th scope="col">Contact</th>
                    <th scope="col">Hostel Type</th> -->
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                  
                <?php if(!empty($hostels)): ?>
                    <?php $__currentLoopData = $hostels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hostel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($hostel->name); ?></td>
                    <td> <?php echo e($hostel->email); ?> </td>
                    <td> <?php echo e($hostel->municipality); ?>-<?php echo e($hostel->ward); ?>,&nbsp;<?php echo e($hostel->city); ?> </td>
                    <!-- <td> <?php echo e($hostel->phone); ?> </td>
                    <td> <?php echo e($hostel->contact); ?> </td>
                    <td> <?php if($hostel->type==0): ?>
                          Boys Hostel
                          <?php elseif($hostel->type==1): ?>
                          Girls Hostel
                          <?php else: ?>
                          Boys and Girls Hostel
                          <?php endif; ?>
                    </td> -->
                    <td>
                      <div class="row">
                      <a class = "btn btn-primary mb-1 btn-sm" href="/admin/hostel/detail/<?php echo e($hostel->id); ?>">Details</a>
                      <a class = "btn btn-primary ml-2 mr-2 mb-1 btn-sm" href = "/admin/hostel/edit/<?php echo e($hostel->id); ?>">Edit</a>
                      <form action="/admin/hostel/delete/<?php echo e($hostel->id); ?>" method="post">
                      <?php echo method_field('DELETE'); ?>
                      <?php echo csrf_field(); ?>
                      <button type="submit" class ="btn btn-danger btn-sm">Delete</button>
                     </form>
                     </div>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
              
                </tbody>
              </table>
              
    
        </div>
      </div>
    </div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\onlineHostelReservation\resources\views/admin/hostel/hostelList.blade.php ENDPATH**/ ?>