
<?php $__env->startSection('content'); ?>
<div class="image-container">
    <div class="image">
    <img src="<?php echo e(asset('images/hostel.jpg')); ?>" alt="" srcset="">
    </div>
</div>
<style>
        .search-tab{
                margin-top: -300px !important;
        }
</style>
<div class="container search-tab">
<h3>Check Availability</h3>
<form action="/hostel/search" method="post">
<?php echo csrf_field(); ?>
<div class="row search-tab-row">
<div class="col-12 .col-xs-12 .col-sm-12 .col-md-6 col-lg-4 col-xl-4 search-place">
    <p>Search Your Place</p>
    <select id="search-place" name="city" class="form-control">
        <option value="">Search By Location</option>
        <?php if(!empty($all)): ?>
        <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hostel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($hostel->city); ?>"><?php echo e($hostel->city); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>    
  </select>
</div>

<div class="col-12 .col-xs-12 .col-sm-12 .col-md-6 col-lg-4 col-xl-4 search-place">

    <p>Hostel Types</p>
 <select id="inputState" name="type" class="form-control">
        <option value ="">Choose...</option>
        <option value="0">Boys Hostel</option>
        <option value="1">Girls Hostel</option>
        <option value="2">Boys and Girls Hostel</option>
        
  </select>
</div>

<div class="col-12 .col-xs-12 .col-sm-12 .col-md-6 col-lg-3 col-xl-3  button-column">

<button id = "search-button" type = "submit">SEARCH</button>

</div>


</div>
</form>
</div>
<div class="container-fluid hostel-lists">
    <p id = "hostel-lists-heading text-uppercase">Available <?php if(!empty($city)): ?>Hostels Available From <?php echo e($city); ?> <?php else: ?> AVAILABLE HOSTELS <?php endif; ?> </p>

  <div class="row hostel-lists-container">
<?php if(!empty($hostels)): ?>
<?php $__currentLoopData = $hostels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hostel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-12 col-xs-12 col-sm-12 col-md-6 col-lg-4 col-xl-3 hostel-lists-division">
          <a href = "#"><img src="<?php echo e(asset('/uploads/'.$hostel['image'])); ?>" alt="" srcset=""></a>
          <div class="hostel-lists-text-section">
            <p><?php echo e($hostel['name']); ?></p>
            <p><?php echo e($hostel['municipality']); ?>-<?php echo e($hostel['ward']); ?>,<?php echo e($hostel['city']); ?></p>
            <button class = "verified-container"> <img id = "verified" style = "width:15px;height:15px;" src="<?php echo e(asset('images/tick.svg')); ?>" alt="" srcset=""> MyHostel Verified</button>
            <p>NRP:<?php echo e($hostel['price']); ?></p>
            <p><?php if($hostel['room']==0): ?>
                Single Bed With Attached Bathroom
              <?php elseif($hostel['room']==1): ?>
                Single Bed With non-attached Bathroom
              <?php elseif($hostel['room']==2): ?>
                shared Bed With Attached Bathroom
              <?php else: ?>
                shared Bed With non-attached Bathroom
              <?php endif; ?>
                per month</p>
                <a href="#"><button class = "view-details">View Details</button></a>
                <a href="#"><button class = "book-now">Book Now</button></a>
         </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.navbar.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\onlineHostelReservation\resources\views/user/hostels/search.blade.php ENDPATH**/ ?>