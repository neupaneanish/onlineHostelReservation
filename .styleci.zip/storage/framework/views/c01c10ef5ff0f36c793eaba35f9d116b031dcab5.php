
<?php $__env->startSection('content'); ?>
<div class="image-container">
    <div class="image">
    <img src="<?php echo e(asset('images/hostel.jpg')); ?>" alt="" srcset="">
    </div>
</div>
<div class="container search-tab">
<h3>Check Availability</h3>
<form action="/hostel/search" method="post">
<?php echo csrf_field(); ?>
<div class="row search-tab-row">
<div class="col-12 .col-xs-12 .col-sm-12 .col-md-6 col-lg-4 col-xl-4 search-place">
    <p>Search Your Place</p>
    <select id="search-place" name="city" class="form-control">
        <option value="">Search By Location</option>
        <?php if(!empty($hostels)): ?>
        <?php $__currentLoopData = $hostels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hostel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($hostel->city); ?>"><?php echo e($hostel->city); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>    
  </select>
</div>

<div class="col-12 .col-xs-12 .col-sm-12 .col-md-6 col-lg-4 col-xl-4 search-place">

    <p>Hostel Types</p>
 <select id="inputState" name="type" class="form-control">
        <option value ="">Choose...</option>
        <option value="0">Boys Hostel</option>
        <option value="1">Girls Hostel</option>
        <option value="2">Boys and Girls Hostel</option>
        
  </select>
</div>

<div class="col-12 .col-xs-12 .col-sm-12 .col-md-6 col-lg-3 col-xl-3  button-column">

<button id = "search-button" type = "submit">SEARCH</button>

</div>


</div>
</form>
</div>
<div class="container-fluid hostel-swiper">
    <p>Boys Hostels</p>
     <!-- Swiper -->

  <div class="swiper-container hostel-swiper-container">
    <div class="swiper-wrapper">
      <?php if(!empty($boys)): ?>
      <?php $__currentLoopData = $boys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $boy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="swiper-slide hostel-swiper-slide">
          <a href = "/hostel/detail/<?php echo e($boy['id']); ?>"><img src="<?php echo e(asset('/uploads/'.$boy['image'])); ?>" alt="" srcset=""></a>
          <div class="hostel-swiper-text-section">
            <p><?php echo e($boy['name']); ?></p>
            <p> <?php echo e($boy['municipality']); ?>-<?php echo e($boy['ward']); ?>,<?php echo e($boy['city']); ?> </p>
            <button class = "verified-container"> <img id = "verified" style = "width:15px;height:15px;" src="<?php echo e(asset('images/tick.svg')); ?>" alt="" srcset=""> MyHostel Verified</button>
            <p>NRP:<?php echo e($boy['price']); ?></p>
            <p><?php if($boy['room']==0): ?>
            Single Bed With Attached Bathroom
              <?php elseif($boy['room']==1): ?>
              Single Bed With non-attached Bathroom
              <?php elseif($boy['room']==2): ?>
              shared Bed With Attached Bathroom
              <?php else: ?>
              shared Bed With non-attached Bathroom
              <?php endif; ?>
             per month</p>
            <a href="#"><button class = "book-now">Book Now</button></a>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    
    </div>
    <!-- Add Arrows -->
    <div class="swiper-button-next swiper-button"></div>
    <div class="swiper-button-prev swiper-button"></div>
  </div>
  
    <script>
        var swiper = new Swiper('.hostel-swiper-container', {
        slidesPerView: 1,
        spaceBetween: 30,
        freeMode: true,
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        breakpoints: {
            // when window width is >= 993px
            1350: {
            slidesPerView: 4,
            spaceBetween: 30
            },
            993: {
            slidesPerView: 3,
            spaceBetween: 30
            },
            768: {
            slidesPerView: 2,
            spaceBetween: 30
            },
        },
        watchSlidesVisibility: true,
        watchSlidesProgress: true,
        });
    </script>
</div>


<div class="container-fluid hostel-swiper">
    <p>Girls Hostels</p>
     <!-- Swiper -->
     <div class="swiper-container hostel-swiper-container1"></a>
        <div class="swiper-wrapper">
          <?php if(!empty($girls)): ?>
          <?php $__currentLoopData = $girls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $boy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="swiper-slide hostel-swiper-slide">
          <a href = "#"><img src="<?php echo e(asset('/uploads/'.$boy['image'])); ?>" alt="" srcset=""></a>
          <div class="hostel-swiper-text-section">
            <p><?php echo e($boy['name']); ?></p>
            <p> <?php echo e($boy['municipality']); ?>-<?php echo e($boy['ward']); ?>,<?php echo e($boy['city']); ?> </p>
            <button class = "verified-container"> <img id = "verified" style = "width:15px;height:15px;" src="<?php echo e(asset('images/tick.svg')); ?>" alt="" srcset=""> MyHostel Verified</button>
            <p>NRP:<?php echo e($boy['price']); ?></p>
            <p><?php if($boy['room']==0): ?>
            Single Bed With Attached Bathroom
              <?php elseif($boy['room']==1): ?>
              Single Bed With non-attached Bathroom
              <?php elseif($boy['room']==2): ?>
              shared Bed With Attached Bathroom
              <?php else: ?>
              shared Bed With non-attached Bathroom
              <?php endif; ?>
             per month</p>
            <a href="#"><button class = "book-now">Book Now</button></a>
        </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>

        </div>
        <!-- Add Arrows -->
        <div class="swiper-button-next swiper-button"></div>
        <div class="swiper-button-prev swiper-button"></div>
      </div>
  
    <script>
        var swiper = new Swiper('.hostel-swiper-container1', {
        slidesPerView: 1,
        spaceBetween: 30,
        freeMode: true,
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        breakpoints: {
            // when window width is >= 993px
            1350: {
            slidesPerView: 4,
            spaceBetween: 30
            },
            993: {
            slidesPerView: 3,
            spaceBetween: 30
            },
            768: {
            slidesPerView: 2,
            spaceBetween: 30
            },
        },
        watchSlidesVisibility: true,
        watchSlidesProgress: true,
        });
    </script>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.navbar.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\onlineHostelReservation\resources\views/user/home/home.blade.php ENDPATH**/ ?>