
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="row">
    <div class="col-sm-12 col-md-4 col-lg-3 quick-navigation-parent">
        <div class="quick-navigation">
            <h3>Quick Navigation</h3>
            <p>Hostel Management</p>
            <a href="/admin/hostel/create"><li>Add Hostel</li></a>
            <a href="/admin/hostel"><li>Hostels List</li></a>
            <a href="/admin/hostel/manageImage"><li class = "active">Manage Images</li></a>
        </div>
    </div>

    <div class="col-sm-12 col-md-8 col-lg-9 left-section-container">
    <?php if(!empty($rooms)): ?>
                    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="add-hostel">
        <h2 class = "user-details-heading uppercase">HOSTEL ROOM DETAILS </h2>
        <div class="row">

            <div class="col-12 col-xs-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">
                <div class="user-details-image-container">
                <img src="<?php echo e(asset('/uploads/'.$room->image)); ?>" alt="" srcset="">
                </div>
                <h2 class = "user-details-heading uppercase"><?php echo e($room->name); ?> </h2>
            </div>
            
            <div class="col-12 col-xs-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">
                <div class = "user-details-info-container">
                    
                <div class="info-container">
                        <p>Hostel Name:</p>
                        <p> <?php echo e($room->name); ?></p>
                    </div>   
                <div class="info-container">
                        <p>Hostel Room No.:</p>
                        <p> <?php echo e($room->room_no); ?></p>
                    </div>
                    <div class="info-container">
                        <p>Room Type :</p>
                        <p>
                        <?php if($room->room_type==0): ?> 
                        Single Bed With Attached Bathroom
                        <?php elseif($room->room_type==0): ?>
                        Single Bed With non-attached Bathroom 
                        <?php elseif($room->room_type==0): ?>
                        Multiple Bed With Attached Bathroom
                        <?php else: ?>
                        Multiple Bed With non-attached Bathroom
                        <?php endif; ?> 
                        </p>
                    </div>
                    <div class="info-container">
                        <p>Price             :</p>
                        <p>     <?php echo e($room->price); ?></p>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    
                </div>
                <?php if(!empty($rooms)): ?>
                    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row mt-5">
                <a class = "btn btn-primary ml-2 mr-2 mb-1" href = "/admin/hostel/room/<?php echo e($room->roomId); ?>/edit">Edit</a>
                <a class = "btn btn-primary ml-2 mr-2 mb-1" href = "/admin/hostel/room/<?php echo e($room->hostel); ?>">Add Room</a>
                <a class = "btn btn-primary ml-2 mr-2 mb-1" href = "/admin/hostel/room/view/<?php echo e($room->hostel); ?>">View Room</a>
                <form action="/admin/hostel/room/delete/<?php echo e($room->hostel); ?>" method="post">
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class = "btn btn-danger ml-2 mr-2 mb-1" href = "/admin/hostel/room/delete/<?php echo e($room->hostel); ?>">Delete</button>    
            </form>
            </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
        </div>
    </div>
    </div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\onlineHostelReservation\resources\views/admin/rooms/roomDetails.blade.php ENDPATH**/ ?>