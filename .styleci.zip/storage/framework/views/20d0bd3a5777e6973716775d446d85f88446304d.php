
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="row">
    <div class="col-sm-12 col-md-4 col-lg-3 quick-navigation-parent">
        <div class="quick-navigation">
            <h3>Quick Navigation</h3>
            <p>Hostel Management</p>
            <a href="/admin/hostel/create"><li>Add Hostel</li></a>
            <a href="/admin/hostel"><li class = "active">Hostels List</li></a>
            <a href="/admin/hostel/manageImage"><li>Manage Images</li></a>
        </div>
    </div>

    <div class="col-sm-12 col-md-8 col-lg-9 left-section-container">
        <div class="add-hostel">
        <h2 class = "user-details-heading">Hostel Details</h2>
        <div class="row">
            <div class="col-12 col-xs-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">
                <div class="user-details-image-container">
                    <?php if(!empty($hostel->image)): ?>
                <img src="<?php echo e(asset('/uploads/'.$hostel->image)); ?>" alt="<?php echo e(asset('/images/'.'6.jpg')); ?>" srcset="">
                <?php else: ?>
                <img src="<?php echo e(asset('images/6.jpg')); ?>" alt="" srcset="">
                <?php endif; ?>
                </div>
            </div>
            <div class="col-12 col-xs-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">
                <div class = "user-details-info-container">
                    <div class="info-container">
                        <p>Hostel Name      :</p>
                        <p>     <?php echo e($hostel->name); ?></p>
                    </div>
                    <div class="info-container">
                        <p> Email Address   :</p>
                        <p>     <?php echo e($hostel->email); ?></p>
                    </div>
                    <div class="info-container">
                        <p>City             :</p>
                        <p>     <?php echo e($hostel->city); ?></p>
                    </div>
                    <div class="info-container">
                        <p>Address          :</p>
                        <p>     <?php echo e($hostel->municipality); ?>-<?php echo e($hostel->ward); ?></p>
                    </div>
                    <div class="info-container">
                        <p>Hostel Type      :</p>
                        <p>
                            <?php if($hostel->type== 0 ): ?>
                            Boys Hostel
                            <?php elseif($hostel->type== 1 ): ?>
                            Girls Hostel
                            <?php else: ?>
                            Boys and Girls Hostel
                            <?php endif; ?>
                        </p>
                    </div>
                    <div class="info-container">
                        <p>Total no. of Rooms:</p>
                        <p><?php echo e($hostel->totalRoom); ?></p>
                    </div>
                <div class="info-container">
                        <p>Total no of Student :</p>
                        <p>200</p>
                    </div>
                    <div class="info-container">
                        <p>Description      :</p>
                        <p><?php echo e($hostel->description); ?></p>
                    </div>
                    <div class="info-container">
                        <p>Account Created      :</p>
                        <p><?php echo e($hostel->created_at); ?></p>
                    </div>
                </div>
                
                <a class = "btn btn-primary ml-2 mr-2 mb-1" href = "/admin/hostel/edit/<?php echo e($hostel->id); ?>">Edit</a>
                <a class = "btn btn-primary ml-2 mr-2 mb-1" href = "/admin/hostel/room/<?php echo e($hostel->id); ?>">Add Room</a>
                <a class = "btn btn-primary ml-2 mr-2 mb-1" href = "/admin/hostel/room/view/<?php echo e($hostel->id); ?>">View Room</a>

                
            </div>
        </div>
    </div>
    </div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\onlineHostelReservation\resources\views/admin/hostel/hostelDetails.blade.php ENDPATH**/ ?>