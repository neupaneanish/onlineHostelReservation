@extends('user.navbar.navbar')

@section('content')
<div class="container">
    <div class="booking-container">
        <div class="nobooking">
            <p>You are not logged in!!</p>
        </div>

    </div>
</div>

@include('user.aboutus.footer')
@endsection
