@extends('user.layout.layout')

@section('content')

@endsection