<div class="container-fluid footer">
<div class="row footer-container">
    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 col-xl-4 footer-margin">
        <div class="footer-image-container">
        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="" srcset="">
        </div>
    </div>
<?php 

use Illuminate\Support\Facades\DB;

$data = DB::table('links')->first();
?>

    <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8 col-xl-8 footer-margin">
        <div class="footer-social-container">
            <p id = "social">Social Platforms</p>
            
            <div class="footer-flex">
                <a href="<?php echo e($data->facebook); ?>" ><img src="<?php echo e(asset('images/facebook.svg')); ?>" alt="" srcset="">Facebook</a>
            </div>
            <div class="footer-flex">
                <a href="<?php echo e($data->instagram); ?>"><img src="<?php echo e(asset('images/insta.svg')); ?>" alt="" srcset="">Instagram</a>
            </div>
            <div class="footer-flex">
                <a href="<?php echo e($data->youtube); ?>"><img src="<?php echo e(asset('images/youtube.svg')); ?>" alt="" srcset="">YouTube</a>
            </div>
            <div class="footer-flex">
                <a href="<?php echo e($data->whatsapp); ?>"><img src="<?php echo e(asset('images/watsapp.svg')); ?>" alt="" srcset="">Watsapp</a>
            </div>
        </div>
    </div>
</div>
</div><?php /**PATH C:\xampp\htdocs\onlineHostelReservation\resources\views/user/aboutus/footer.blade.php ENDPATH**/ ?>