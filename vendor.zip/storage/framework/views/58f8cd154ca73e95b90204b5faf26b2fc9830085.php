
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="row">
    <div class="col-sm-12 col-md-4 col-lg-3 quick-navigation-parent">
    <div class="quick-navigation">
            <h3>Quick Navigation</h3>
            <p>Admin Management</p>
            <a href="/admin/register"><li>Create Admins</li></a>
            <a href="/admin/show"><li class = "active">List Admins</li></a>
        </div>
    </div>

    <div class="col-sm-12 col-md-8 col-lg-9 left-section-container">

      <div class="add-hostel">
          <?php if(session('status')): ?>
      <div class = "error-display">
            <p><?php echo e(session('status')); ?></p>
          </div>
          <?php endif; ?>
        <h3>Name of Administrator : <?php echo e($admin->name); ?></h3>
        <form method="post" action="/admin/password/<?php echo e($admin->id); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
        <div class="form-group row">
            <label for="reset-pass" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

            <div class="col-md-6">
                <input id="password" type="password" name="password" class="form-control" required autocomplete="new-password">
            </div>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div style="text-align: center;width:100%;">
                                        <strong style="color: red;"><?php echo e($message); ?></strong>
                                        </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        
        <div class="form-group row">
            <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>

            <div class="col-md-6">
                <input id="password-confirmation" name="password_confirmation" type="password" class="form-control" required autocomplete="new-password">
            </div>
        </div>

        <div class="form-group row ">
            <div class="col-md-12 offset-md-4">
                <button type="submit" class="btn btn-primary">
                    <?php echo e(__('Reset Password')); ?>

                </button>
            </div>
        </div>
        </form>
    </div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\onlineHostelReservation\resources\views/admin/mgmtAdmin/reset.blade.php ENDPATH**/ ?>