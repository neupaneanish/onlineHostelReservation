

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="booking-container">
        <div class="nobooking">
            <p>You are not logged in!!</p>
        </div>

    </div>
</div>

<?php echo $__env->make('user.aboutus.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.navbar.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\onlineHostelReservation\resources\views/user/booking/noBooking.blade.php ENDPATH**/ ?>