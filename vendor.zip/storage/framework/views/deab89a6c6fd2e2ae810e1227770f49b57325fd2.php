
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="row">
    <div class="col-sm-6 col-md-4 col-lg-3 quick-navigation-parent">
        <div class="quick-navigation">
            <h3>Quick Navigation</h3>
            <p>Hostel Management</p>
            <a href="/admin/hostel/create"><li>Add Hostel</li></a>
            <a href="/admin/hostel"><li>Hostels List</li></a>
            <a href="/admin/hostel/manageImage"><li class = "active">Manage Images</li></a>
        </div>
    </div>

    <div class="col-sm-6 col-md-8 col-lg-9 left-section-container">
      <div class="add-hostel">
      <?php if(session('message')): ?>
            <div class = "error-display" style="background:green">
                <p><?php echo e(session('message')); ?></p>
              </div>
              <?php endif; ?>
        <h3>Hostel Name:  <?php echo e($hostel->name); ?></h3>
        <div class="list-hostel">
        <div class="row">
        <form action="/admin/hostel/addImage" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div>
                <input type="hidden" name="id" value='<?php echo e($hostel->id); ?>'>
                <!-- <label for="image"> Images </label> -->
                                <div class="form-group">
                                    <input type="file" name="image[]" class="form-control" id="images" multiple />

                                </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary"> Upload Images </button>
                        </div>
      
      
               

        </form>
        </div>
              
    
        </div>
      </div>
    </div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\onlineHostelReservation\resources\views/admin/images/editImage.blade.php ENDPATH**/ ?>