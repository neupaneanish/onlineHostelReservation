
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="row">
    <div class="col-sm-12 col-md-4 col-lg-3 quick-navigation-parent">
    <div class="quick-navigation">
            <h3>Quick Navigation</h3>
            <p>Web Management</p>
            <a href="/admin/web/footer"><li class = "active">Footer Management</li></a>
            <a href="/admin/web/about"><li>Aboutus Management</li></a>
        </div>
    </div>

    <div class="col-sm-12 col-md-8 col-lg-9 left-section-container">
        <div class="add-hostel">
        <?php if(session('status')): ?>
        <div class = "error-display">
          <p><?php echo e(session('status')); ?></p>
        </div>
        <?php endif; ?>
            <h3>Footer Links</h3>
            <form action="/admin/web/footer" method="post">
          <?php echo csrf_field(); ?>
          
        <div class="admin-footer-section">
            <div class="col-md-6 mb-3">
                <label id = "admin-social" for="facebook">Facebook Link</label>
                <input type="text"  <?php if(!empty($link)): ?> value="<?php echo e($link->facebook); ?>" <?php endif; ?> name="facebook" class="form-control">
              </div>
              <div class="col-md-6 mb-3">
                <label id = "admin-social" for="instagram">Instagram Link</label>
                <input type="text"  <?php if(!empty($link)): ?> value="<?php echo e($link->instagram); ?>" <?php endif; ?> name="instagram" class="form-control">
              </div>
              <div class="col-md-6 mb-3">
                <label id = "admin-social" for="youtube">YouTube Link</label>
                <input type="text"  <?php if(!empty($link)): ?> value="<?php echo e($link->youtube); ?>" <?php endif; ?> name="youtube" class="form-control">
              </div>
              <div class="col-md-6 mb-3">
                <label id = "admin-social" for="watsapp">Watsapp Link</label>
                <input type="text"  <?php if(!empty($link)): ?> value="<?php echo e($link->whatsapp); ?>" <?php endif; ?> name="whatsapp" class="form-control">
                <?php if(session('message')): ?>
                <strong style="color: red;"><?php echo e(session('message')); ?></strong>
              <?php endif; ?>
              </div>
             
              <button type="submit" style="margin-left:1.5%" class="col-md-2 mt-3 btn btn-primary">Save</button>
        </div>
        </form>
    </div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\onlineHostelReservation\resources\views/admin/web/footer.blade.php ENDPATH**/ ?>