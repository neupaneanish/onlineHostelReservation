
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="row">
 <div class="col-sm-12 col-md-12 col-lg-12 left-section-container">
    

<div class="list-hostel">
  <h3></h3>
  <p id = "booking-list">List of Bookings</p>
</div>
<?php if(!empty($bookings)): ?>
<?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="add-hostel mb-5">
        <div class="list-hostel">
              <div class="admin-booking-container">
                    <div class="admin-booking-image-container">
                    <img src="<?php echo e(asset('/uploads/'.$booking->image)); ?>" alt="" srcset="">
                    </div>
                    <div class="admin-booking-text-section">
                    <div class="booking-information">
                        <p>Username:</p>
                        <p><?php echo e($booking->email); ?></p>
                    </div>
                    <div class="booking-information">
                        <p>fullname:</p>
                        <p><?php echo e($booking->fullname); ?></p>
                    </div>
                    <div class="booking-information">
                        <p>Booked Hostel:</p>
                        <p><?php echo e($booking->name); ?></p>
                    </div>
                    <div class="booking-information">
                        <p>Room-Type:</p>
                        <p>
                        <?php if($booking->room_type==0): ?>
                        Single Bed with attached bathrooms
                        <?php elseif($booking->room_type==1): ?>
                        Single Bed With non-attached Bathroom
                        <?php elseif($booking->room_type==2): ?>
                        shared Bed With Attached Bathroom
                        <?php else: ?>
                        shared Bed With non-attached Bathroom
                        <?php endif; ?>
                       </p>
                    </div>
                    <div class="booking-information">
                        <p>Room No:</p>
                        <p><?php echo e($booking->room_no); ?></p>
                    </div>
                    <div class="booking-information">
                        <p>Booked Date</p>
                        <p><?php echo e($booking->created_at); ?></p>
                    </div>
                    <div class="booking-information">
                        <p>Phone No:</p>
                        <p><?php echo e($booking->mobile); ?></p>
                    </div>
                </div>
              </div>
            
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
<!-- message here -->
    <?php endif; ?>

</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\onlineHostelReservation\resources\views/admin/adminBooking/listBooking.blade.php ENDPATH**/ ?>