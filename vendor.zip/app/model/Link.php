<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Link extends Model
{
    protected $fillable = [
    'facebook','instagram','youtube','whatsapp',
    ];
}
