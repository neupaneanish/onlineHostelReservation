<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Web extends Model
{
    protected $fillable = ['tel_no','mobile','email','iframe'];
}
